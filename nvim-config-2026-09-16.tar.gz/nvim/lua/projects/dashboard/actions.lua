local M = {}

function M.build()
    return {
        {
            type = "button",
            val = "  [ P ]  Project Browser",
            on_press = function()
                require("projects.browser").open()
            end,
            opts = {
                width = 60,
                position = "center",
                shortcut = "P",
                cursor = 1,
            },
        },

        {
            type = "button",
            val = "  [ C ]  Neovim Config",
            on_press = function()
                vim.cmd(
                    "edit "
                    .. vim.fn.fnameescape(
                        vim.fn.expand("~/.config/nvim/init.lua")
                    )
                )
            end,
            opts = {
                width = 60,
                position = "center",
                shortcut = "C",
                cursor = 1,
            },
        },

        {
            type = "button",
            val = "  [ G ]  GitHub Directory",
            on_press = function()
                vim.cmd(
                    "cd "
                    .. vim.fn.fnameescape(
                        vim.fn.expand("~/Documents/github")
                    )
                )

                vim.cmd("enew")
            end,
            opts = {
                width = 60,
                position = "center",
                shortcut = "G",
                cursor = 1,
            },
        },
    }
end

return M
