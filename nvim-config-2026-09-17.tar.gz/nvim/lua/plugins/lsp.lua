return {
    "neovim/nvim-lspconfig",

    config = function()
        vim.lsp.config("clangd", {
            cmd = {
                vim.fn.stdpath("data") .. "/mason/bin/clangd",
            },
        })

        vim.lsp.enable("clangd")

        vim.lsp.config("ts_ls", {
            cmd = {
                vim.fn.stdpath("data") .. "/mason/bin/typescript-language-server",
                "--stdio",
            },
        })

        vim.lsp.enable("ts_ls")

        vim.lsp.config("pyright", {
            cmd = {
                vim.fn.stdpath("data") .. "/mason/bin/pyright-langserver",
                "--stdio",
            },
        })

        vim.lsp.enable("pyright")
        vim.lsp.config("ruff", {
    cmd = {
        vim.fn.stdpath("data") .. "/mason/bin/ruff",
        "server",
    },
})

vim.lsp.enable("ruff") 
    end,
}
