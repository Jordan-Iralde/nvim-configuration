return {
    "neovim/nvim-lspconfig",

    config = function()
        vim.lsp.config("clangd", {
            cmd = {
                vim.fn.stdpath("data") .. "/mason/bin/clangd",
            },
        })

        vim.lsp.enable("clangd")
    end,
}
