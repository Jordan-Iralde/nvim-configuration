-- Leader
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- Tree-sitter parsers
vim.opt.rtp:prepend(vim.fn.stdpath("data") .. "/site")

-- lazy.nvim
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"

vim.opt.rtp:prepend(lazypath)

-- Core configuration
require("config.options")
require("config.keymaps")

-- Plugins
require("lazy").setup("plugins")
