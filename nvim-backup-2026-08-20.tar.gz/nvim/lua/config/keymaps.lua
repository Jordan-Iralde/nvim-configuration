local map = vim.keymap.set

-- Find
map("n", "<leader>ff", "<cmd>Telescope find_files<cr>", {
    desc = "Find files",
})

map("n", "<leader>fg", "<cmd>Telescope live_grep<cr>", {
    desc = "Find text",
})

map("n", "<leader>fb", "<cmd>Telescope buffers<cr>", {
    desc = "Find buffers",
})

map("n", "<leader>fh", "<cmd>Telescope help_tags<cr>", {
    desc = "Find help",
})

-- Explorer
map("n", "<leader>e", "<cmd>Oil<cr>", {
    desc = "Explorer",
})

-- Save
map("n", "<leader>w", "<cmd>write<cr>", {
    desc = "Save",
})

-- Quit
map("n", "<leader>q", "<cmd>quit<cr>", {
    desc = "Quit",
})

-- Diagnostics
map("n", "<leader>xx", "<cmd>Trouble diagnostics toggle<cr>", {
    desc = "Diagnostics",
})

-- Buffers
map("n", "<leader>bn", "<cmd>bnext<cr>", {
    desc = "Next buffer",
})

map("n", "<leader>bp", "<cmd>bprevious<cr>", {
    desc = "Previous buffer",
})

map("n", "<leader>bd", "<cmd>bdelete<cr>", {
    desc = "Delete buffer",
})

-- Splits
map("n", "<leader>sv", "<cmd>vsplit<cr>", {
    desc = "Vertical split",
})

map("n", "<leader>sh", "<cmd>split<cr>", {
    desc = "Horizontal split",
})

-- Window navigation
map("n", "<C-h>", "<C-w>h", {
    desc = "Move left",
})

map("n", "<C-j>", "<C-w>j", {
    desc = "Move down",
})

map("n", "<C-k>", "<C-w>k", {
    desc = "Move up",
})

map("n", "<C-l>", "<C-w>l", {
    desc = "Move right",
})
